package rushhour.model;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;




public class MoveTest{

    @Test
    public void createMoveTest(){

        

        Move move = new Move('U', Direction.UP);

        assertEquals(move.getSymbol(), 'U');
        assertEquals(move.getDir(), Direction.UP);

    }

    
}