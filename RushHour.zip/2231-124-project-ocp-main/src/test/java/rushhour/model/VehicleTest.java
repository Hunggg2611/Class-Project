package rushhour.model;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.security.spec.ECFieldF2m;


public class VehicleTest {


    @Test
    public void createVehicleTest(){

        Vehicle vehicle = new Vehicle('H', new Position(3, 3), new Position(3, 5));

        int frontRow = 3;
        int frontCol = 5;
        int backRow = 3;
        int backcol = 3;

        assertEquals(vehicle.getBack().getCol(), backcol);
        assertEquals(vehicle.getBack().getRow(), backRow);
        assertEquals(vehicle.getFront().getCol(), frontCol);
        assertEquals(vehicle.getFront().getRow(), frontRow);

    }

    @Test
    public void lengthTest(){
        Vehicle vehicle = new Vehicle('A', new Position(0, 2), new Position(2, 2));
        assertEquals(vehicle.getLength(),2);
    }

    @Test
    public void middleVerticleTest(){
        Vehicle vehicle = new Vehicle('A', new Position(0, 2), new Position(2, 2));
        Position middle = new Position(1, 2);

        assertEquals(vehicle.getMiddle().getRow(), middle.getRow());
        assertEquals(vehicle.getMiddle().getCol(), middle.getCol());
    }

    @Test
    public void middleHorizontalTest(){

        Vehicle vehicle = new Vehicle('A', new Position(0, 3), new Position(0, 5));
        Position middle = new Position(0, 4);

        assertEquals(vehicle.getMiddle().getRow(), middle.getRow());
        assertEquals(vehicle.getMiddle().getCol(), middle.getCol());

    }


    @Test
    public void validMoveHVehicleTest() {

        Vehicle vehicle = new Vehicle('A', new Position(1, 2), new Position(1, 3));

        try {
            vehicle.move(Direction.LEFT);
        } catch (Exception e) {
            e.printStackTrace();
        }
        assertEquals(vehicle.getBack().getCol(),1);
    }

    @Test
    public void validMoveHVehicleTest2(){

        Vehicle vehicle = new Vehicle('A', new Position(1, 2), new Position(1, 3));

        try {
            vehicle.move(Direction.RIGHT);
        } catch (Exception e) {
            e.printStackTrace();
        }
        assertEquals(vehicle.getBack().getCol(),3);
    }

    @Test
    public void validMoveVVehicleTest(){
        Vehicle vehicle = new Vehicle('A', new Position(2, 2), new Position(4, 2));
         try {
            vehicle.move(Direction.UP);
        } catch (Exception e) {
            e.printStackTrace();
        }
        assertEquals(vehicle.getBack().getRow(),3);


    }

     @Test
    public void validMoveVVehicleTest2(){
        Vehicle vehicle = new Vehicle('A', new Position(2, 2), new Position(4, 2));
         try {
            vehicle.move(Direction.DOWN);
        } catch (Exception e) {
            e.printStackTrace();
        }
        assertEquals(vehicle.getBack().getRow(),1);


    }

    @Test
    public void validMoveVerticleMiddleTest(){

        Vehicle vehicle = new Vehicle('A', new Position(2, 2), new Position(4, 2));
        try {
            vehicle.move(Direction.DOWN);
        } catch (Exception e) {
            e.printStackTrace();
        }

        Position middle = vehicle.getMiddle();

        assertEquals(middle.getCol(),2);
        assertEquals(middle.getRow(),2);

    }

    @Test
    public void validMoveHorizontalMiddleTest(){
        Vehicle vehicle = new Vehicle('A', new Position(2, 2), new Position(2, 4));

         try {
            vehicle.move(Direction.RIGHT);
        } catch (Exception e) {
            e.printStackTrace();
        }

        Position middle = vehicle.getMiddle();

        assertEquals(middle.getCol(),4);
        assertEquals(middle.getRow(),2);

    }

    @Test
    public void updatingPositionsMiddleVehicles(){

         Vehicle vehicle = new Vehicle('A', new Position(0, 2), new Position(2, 2)); // Creates a vertical vehicle

         try{
            vehicle.move(Direction.UP);
            vehicle.move(Direction.UP);
         }
         catch(Exception e){
            e.printStackTrace();
         }

         Position front = vehicle.getFront();
         Position middle = vehicle.getMiddle();
         Position back = vehicle.getBack();

         assertEquals(front.getRow(),4);
         assertEquals(front.getCol(),2);

         assertEquals(middle.getRow(), 3);
         assertEquals(middle.getCol(), 2);

         assertEquals(back.getRow(), 2);
         assertEquals(back.getCol(), 2);
        
    }




    //This test does not complete because of the exception which is a good thing???
    //Commented out because the incompletion of test displays as a failure
    // @Test
    // public void invalidMoveVehicleTest() throws Exception{ 
    //     Vehicle vehicle = new Vehicle('A', new Position(0, 3), new Position(0, 5));
    //     boolean thrown = false;

    //     try {
    //         vehicle.move(Direction.UP);
            
    //     } catch (RushHourException e) {
    //         thrown = true;
    
    //     }
    //     assertEquals(thrown, true);
    // }

    
    
}



