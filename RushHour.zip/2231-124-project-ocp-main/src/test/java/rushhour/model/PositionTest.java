package rushhour.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class PositionTest{

    @Test
    public void createPositionTest(){

        Position pos = new Position(1, 1);
        int row = pos.getRow();
        int col = pos.getCol();

        assertEquals(1, row);
        assertEquals(1, col);
    }

}