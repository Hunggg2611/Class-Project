package rushhour.view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import rushhour.model.Direction;
import rushhour.model.Move;
import rushhour.model.RushHour;
import rushhour.model.RushHourSolver;

public class RushHourCLI {


    public RushHourCLI(){
    }

    public static Direction giveDirection(String input){

        if(input.equals("UP")){
            return Direction.UP;
        }
        if(input.equals("DOWN")){
            return Direction.DOWN;
        }
        if(input.equals("LEFT")){
            return Direction.LEFT;
        }
        else{
            return Direction.RIGHT;
        }

    }

    public static String printFileChoices(){
        return ("Game Options: " + '\n' + "Choice 1: data/03_00.csv" + '\n' + "Choice 2: data/04_00.csv" + '\n' + "Choice 3: data/07_00.csv" + '\n' + "Choice 4: data/08_00.csv" + '\n' + "Choice 5: data/13_00.csv");
    }

    public static String printHelpMessage(){
        return ("List of Commands: " + '\n'
                +"'Help' -- Displays List of Commands" + '\n'
                +"'Move' -- Start Making a Move on the Current Board" +'\n'
                +"'Hint' -- Gives a Hint to an Available Move" + '\n'
                +"'Reset' -- Clears the Current Board and Returns to Start State" + '\n'
                +"'Quit' -- Prompts an Exit Message to Leave the Game" + '\n'
                + "MOVES ARE MADE AS <symbol> <direction>"
                );

    }

    public ArrayList<String> makeFilesList(){
        ArrayList<String> filesList = new ArrayList<>();
        filesList.add("data/03_00.csv");
        filesList.add("data/04_00.csv");
        filesList.add("data/07_00.csv");
        filesList.add("data/08_00.csv");
        filesList.add("data/13_00.csv");
        return filesList;
    }

    public RushHour makeRushHour(String fileName) throws IOException{
        return new RushHour(fileName);
    }

    public void playGame(){

        boolean isGameOver = false;
        Scanner scanner = new Scanner(System.in);
        System.out.println(printFileChoices());
        ArrayList<String> files = makeFilesList();
        System.out.println("Enter a File number to match the name of the file you want to play: ");
        int fileInput = Integer.parseInt(scanner.nextLine());
        String fileName = files.get(fileInput-1);

        while(!isGameOver){
           
            try {
                
                RushHour rushHourBoard = new RushHour(fileName);
                System.out.println("Enter 'Help' for a list of Commands");
            
            String input = scanner.nextLine();

            if(input.equals("Help")){
                System.out.println(printHelpMessage());
            }

            if(input.equals("Quit")){
                System.out.println("Quit? [Y/N]");
                String quitInput = scanner.next();
                if(quitInput.equals("Y")){
                    System.out.println("Goodbye, thanks for playing!");
                    break;
                }
            }

            if(input.equals("Move")){
                boolean isDone = false;
                while(!isDone){
                    
                    if(rushHourBoard.isGameOver()){
                        isDone = true;
                        rushHourBoard.printBoard();
                        System.out.println("YOU WIN");
                        break;
                    }
                    rushHourBoard.printBoard();
                    System.out.println("Make a move <symbol> <direction>");
                    String moveInput = scanner.nextLine();
                    if(moveInput.equals("Reset")){
                        rushHourBoard.resetBoard();
                        continue;
                    }
                    if(moveInput.equals("Hint")){
                        ArrayList<Move> moves = rushHourBoard.getPossibleMoves();
                        System.out.println(moves);
                        continue;
                    }
                    if(moveInput.equals("Quit")){
                        System.out.println("Goodbye");
                        break;
                    }
                    if(moveInput.equals("Solve")){
                        RushHourSolver solution = RushHourSolver.solve(rushHourBoard);
                        System.out.println(solution);
                        break;
                    }
                    String[] tokens = moveInput.split(" ");
                    Direction direction;

                    char symbol = moveInput.charAt(0);
                    direction = giveDirection(tokens[1]);

                    Move move = new Move(symbol,direction);

                    try {
                        rushHourBoard.moveVehicle(move);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    System.out.println('\n');

                }
                
            }


            } catch (IOException e) {
                System.out.println("File Error");
                scanner.close();
                e.printStackTrace();                        
            }

           
        }

    }

    public static void main(String[] args){

        RushHourCLI rushHourCLI = new RushHourCLI();
        rushHourCLI.playGame();

    }
    
}
