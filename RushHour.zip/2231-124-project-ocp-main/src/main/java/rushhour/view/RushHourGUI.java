package rushhour.view;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import rushhour.model.Move;
import rushhour.model.RushHour;
import rushhour.model.RushHourSolver;
import rushhour.model.Vehicle;


public class RushHourGUI extends Application {

    private final int BOARDSIZE = 6;
    private RushHour rushhour;
    private String filePath;
    

    
    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("OCP RushHour");

        //Win message label
        Label wonLabel = new Label();
        wonLabel.setVisible(false);
        wonLabel.setTextFill(Color.GREEN);
        wonLabel.setText("YOU WIN!");
        wonLabel.setMinWidth(75);

        //Move count label
        Label countlabel = new Label();
        countlabel.setMinWidth(150);



        //Invalid moves label
        Label invalidMoveLabel = new Label();
        invalidMoveLabel.setText("");
        invalidMoveLabel.setTextFill(Color.RED);
        invalidMoveLabel.setEllipsisString(null);
        invalidMoveLabel.setMinWidth(100);
        
       


        //Creating the gridpane to store the game board
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(100));
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setBackground(new Background(
            new BackgroundFill(Color.GRAY, null, null)
        ));

        // Setting the background images
        for (int row = 0; row < BOARDSIZE ; row++) {
            for (int col = 0; col < BOARDSIZE; col++) {
              
                ImageView imageView = new ImageView("file:data/GUI/GridPaneBackground.png");
                imageView.setFitHeight(100);
                imageView.setFitWidth(100);
                gridPane.add(imageView, col, row);
            }
        }

        //Creating the hbox to hold the game buttons
        HBox hbox = new HBox();
        HBox.setHgrow(hbox, Priority.ALWAYS);
        HBox.setHgrow(hbox, Priority.ALWAYS);
        hbox.setBackground(new Background(
            new BackgroundFill(Color.LIGHTCYAN, null, null)
        ));

        
        //Setting up the SOLVE button
        Button solveButton = new Button();
        solveButton.setText("Solve");
        solveButton.setMinWidth(50);

        solveButton.setOnAction(e -> {
            RushHourSolver solution = new RushHourSolver(rushhour);
            solution.solve(rushhour);
            
        });

        //Setting up the hint button
        Label hintLabel = new Label();
        Button hintButton = new Button();
        hintButton.setMinWidth(50);
        hintButton.setText("Hint");
        hintButton.setOnAction(e -> {
            ArrayList<Move> possibleMoves = rushhour.getPossibleMoves();
            hintLabel.setText(possibleMoves.get(new Random().nextInt(possibleMoves.size())).toString());
        });

        //Setting up the move button and text field to grab moves
        TextField movTextField = new TextField();
        movTextField.setPromptText("Enter a move");
        movTextField.setMinWidth(75);
        movTextField.setMaxWidth(75);

        Button moveButton = new Button();
        moveButton.setText("Make Move");
        moveButton.setMinWidth(120);
        moveButton.setOnAction( e->{

        String moveInput = movTextField.getText();
        String[] tokens = moveInput.split(" ");
        char moveSymbol = moveInput.charAt(0);
        rushhour.model.Direction direction = RushHourCLI.giveDirection((String)tokens[1]);
        Move move = new Move(moveSymbol, direction);
        Vehicle vehicle = null;
        boolean moved = false;

        for (Vehicle vehicle1 : this.rushhour.getVehiclesList()) {
            if(vehicle1.getSymbol() == move.getSymbol())
            vehicle = vehicle1;
        }

        try{

            if(rushhour.board.checkMove(move, vehicle)){

            remove1Vehicle(vehicle, gridPane);
            this.rushhour.moveVehicle(move);
            add1Vehicle(vehicle,gridPane);
            countlabel.setText("Move Count: " + this.rushhour.getMoveCount());
            invalidMoveLabel.setText("");
            moved = true;


        //ON WIN CONDITION MOVE/HINT BUTTONS DISABLE
            if(this.rushhour.isGameOver()){
                wonLabel.setVisible(true);
                moveButton.setDisable(true);
                hintButton.setDisable(true);
                solveButton.setDisable(true);
            }
        }

            if(!rushhour.board.checkMove(move, vehicle) && !moved){
                invalidMoveLabel.setText("  " + vehicle.getOrientation() + " VEHICLE CAN'T MOVE " + move.getDir().getDirectionString().toUpperCase());
            }

        }catch(ArrayIndexOutOfBoundsException g){
            if(!moved){
                
                invalidMoveLabel.setText("   OUT OF BOUNDS");
            }
        }
        });

        //Setting up the reset board button
        Button resetButton = new Button();
        resetButton.setMinWidth(50);
        resetButton.setText("Reset");
        resetButton.setOnAction(e -> {
            clearBoard(gridPane);
            try {
                this.rushhour = new RushHour(filePath);
            } catch (IOException e1) {
            }
            setUpBoard(gridPane, rushhour);
            countlabel.setText("Move Count: " + this.rushhour.getMoveCount());
            wonLabel.setText("");
            moveButton.setDisable(false);
            hintButton.setDisable(false);
            solveButton.setDisable(false);
        });


        
        //Load the proper game file fileButton 
        //This button will add in the MoveButton and MoveTexfield upon file found success
        TextField fileNameInput = new TextField();
        fileNameInput.setPromptText("Enter a file by number");
        Button fileButton = new Button();
        fileButton.setText("Load File");
        fileButton.setOnAction(e -> {

            String fileString = fileNameInput.getText();
            Integer fileint = Integer.parseInt(fileString);
            if(!fileString.isEmpty()){
                try{

                    String file = fileNameConverter(fileint);
                    this.filePath = file;
                    this.rushhour = new RushHour(file);
                    this.rushhour.printBoard();

                    hbox.getChildren().remove(fileNameInput);
                    hbox.getChildren().remove(fileButton);

                    setUpBoard(gridPane, rushhour);
                    countlabel.setText("Move Count: " + this.rushhour.getMoveCount());
                    //These things only get added after a file is successfully found
                    hbox.getChildren().addAll(moveButton, movTextField, hintButton, hintLabel, resetButton,solveButton, countlabel,
                    invalidMoveLabel,wonLabel);

                } catch (IOException f) {
                    System.out.println("File Error");
                }
            }
            
        });

       
    

        //ADDING TO THE HBOX
        hbox.getChildren().addAll(fileButton,fileNameInput);
        hbox.setMinWidth(710);
        gridPane.setMinWidth(710);

        //ADDING TO THE GRIDPANE
        gridPane.add(hbox, 0,6,6,1);


        //Setting the stage 
        primaryStage.setScene(new Scene(gridPane));
        primaryStage.setWidth(710); 
        primaryStage.setHeight(710);
        primaryStage.show();
    }


    //BEGIN HELPER FUNCTIONS


    //Helper to convert the file input from a number to string
    private String fileNameConverter(int fileNum){
        if(fileNum == 1){
            return "data/03_00.csv";
        }
        if(fileNum == 2){
            return "data/04_00.csv";
        }
        if(fileNum == 3){
            return "data/07_00.csv";
        }
        if(fileNum == 4){
            return "data/08_00.csv";
        }
        if(fileNum == 5){
            return "data/13_00.csv";
        }
        else{
            return null;
        }

    }

    
   

    //Helper to make a label to represent the cars

    private Label makeVehicleLabel(Color color, char symbol){

        Label label = new Label();
        label.setText(String.valueOf(symbol));
        label.setPadding(new Insets(40));
        label.setAlignment(Pos.CENTER);
        label.setPrefWidth(100);
        label.setPrefHeight(100);
        label.setTextFill(Color.WHITE);

        label.setBackground(new Background(
        new BackgroundFill(color, null, null)
       ));

       return label;
    }

    //Helper to clear the board
    private void clearBoard(GridPane gridPane){
        ArrayList<Vehicle> vehicles = rushhour.getVehiclesList();
        for (Vehicle vehicle : vehicles) {
            remove1Vehicle(vehicle, gridPane);
        }
    }

    //Helper to add the car labels to the board
    private void setUpBoard(GridPane gridpane,RushHour rushhour){

        

        ArrayList<Vehicle> vehicles = rushhour.getVehiclesList();

        for(Vehicle vehicle : vehicles){

            Color color;

            if(vehicle.getSymbol() == 'R'){
                color = Color.RED;
                
            }
            else{

                Random random = new Random();
                color = Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256));
            }

            Label label1 = makeVehicleLabel(color, vehicle.getSymbol());
            Label label2 = makeVehicleLabel(color, vehicle.getSymbol());
            Label label3 = makeVehicleLabel(color, vehicle.getSymbol());

            if(vehicle.getLength() == 1){
                gridpane.add(label1, vehicle.getFront().getCol(), vehicle.getFront().getRow());
                gridpane.add(label2, vehicle.getBack().getCol(), vehicle.getBack().getRow());
            }
            else{
                gridpane.add(label1, vehicle.getFront().getCol(), vehicle.getFront().getRow());
                gridpane.add(label2, vehicle.getBack().getCol(), vehicle.getBack().getRow());
                gridpane.add(label3, vehicle.getMiddle().getCol(), vehicle.getMiddle().getRow());
            }
            
        }

       

    }

    //Helper to remove a vehicle
    private void remove1Vehicle(Vehicle vehicle, GridPane gridpane){

        if(vehicle.length == 1){
            Label label1 = getLabel(gridpane, vehicle.getBack().getCol(), vehicle.getBack().getRow());
            Label label2 = getLabel(gridpane, vehicle.getFront().getCol(), vehicle.getFront().getRow());

            gridpane.getChildren().remove(label1);
            gridpane.getChildren().remove(label2);
        }
        else{

            Label label1 = getLabel(gridpane, vehicle.getBack().getCol(), vehicle.getBack().getRow());
            Label label2 = getLabel(gridpane, vehicle.getFront().getCol(), vehicle.getFront().getRow());
            Label label3 = getLabel(gridpane, vehicle.getMiddle().getCol(), vehicle.getMiddle().getRow());

            gridpane.getChildren().remove(label1);
            gridpane.getChildren().remove(label2);
            gridpane.getChildren().remove(label3);

        }
    }

    //Helper to add 1 vehicle to the board
    private void add1Vehicle(Vehicle vehicle, GridPane gridpane){

        Color color = null;

         if(vehicle.getSymbol() == 'R'){
                color = Color.RED;
                
            }
            else{

                Random random = new Random();
                color = Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256));
            }

            Label label1 = makeVehicleLabel(color, vehicle.getSymbol());
            Label label2 = makeVehicleLabel(color, vehicle.getSymbol());
            Label label3 = makeVehicleLabel(color, vehicle.getSymbol());

            if(vehicle.getLength() == 1){
                gridpane.add(label1, vehicle.getFront().getCol(), vehicle.getFront().getRow());
                gridpane.add(label2, vehicle.getBack().getCol(), vehicle.getBack().getRow());
            }
            else{
                gridpane.add(label1, vehicle.getFront().getCol(), vehicle.getFront().getRow());
                gridpane.add(label2, vehicle.getBack().getCol(), vehicle.getBack().getRow());
                gridpane.add(label3, vehicle.getMiddle().getCol(), vehicle.getMiddle().getRow());
            }
            
        }
    
    //Helper to get a label at a given spot
    private Label getLabel(GridPane gridPane, int col, int row) {

        for (int i = 0; i < gridPane.getChildren().size(); i++) {
            
            if (GridPane.getColumnIndex(gridPane.getChildren().get(i)) == col &&
                    GridPane.getRowIndex(gridPane.getChildren().get(i)) == row &&
                    gridPane.getChildren().get(i) instanceof Label) {
                return (Label) gridPane.getChildren().get(i);
            }
        }
        return null; 
    }

  
    public static void main(String[] args) {
        launch(args);
    }

}






