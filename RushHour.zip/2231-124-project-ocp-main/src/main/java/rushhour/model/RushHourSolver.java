package rushhour.model;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Random;

import backtracker.Backtracker;
import backtracker.Configuration;

public class RushHourSolver implements Configuration{

    private RushHour rushhour;
    private ArrayList<Move> moves;

    public RushHourSolver(RushHour rushhour){
        this.rushhour = rushhour;
        this.moves = new ArrayList<>();
        
    }

    //CHECK THAT THE BOARD IS BEING PROPERLY UPDATED ON EACH SUCCESSOR 
    

    @Override
    public Collection getSuccessors() {

        ArrayList<Configuration> successors = new ArrayList<>();
        Move madeMove;
        ArrayList<Move> possibleMoves = this.rushhour.getPossibleMoves();
        if(this.rushhour.canMoveRedRight()){
            for(Move move : possibleMoves){
                if(move.getSymbol() == 'R' && this.rushhour.board.checkMove(move, this.rushhour.redVehicle) && move.getDir() == Direction.RIGHT){
                    madeMove = move;
                    this.rushhour.moveVehicle(madeMove);
                    this.moves.add(madeMove);
                    RushHour copy = new RushHour(this.rushhour);
                    RushHourSolver suc = new RushHourSolver(copy);
                    successors.add(suc);
                    suc.moves.add(madeMove);
                }
            }

        }else{
            madeMove = possibleMoves.get(new Random().nextInt(possibleMoves.size()-1));
            this.rushhour.moveVehicle(madeMove);
            this.moves.add(madeMove);
            RushHour copy = new RushHour(this.rushhour);
            RushHourSolver suc = new RushHourSolver(copy);
            successors.add(suc);
            suc.moves.add(madeMove);
        }
         
        return successors;
    }

    @Override
    public boolean isValid() {

        if(rushhour.isGameOver()){
            return true;
        }
        else{
            return (!rushhour.isGameOver());
        }
       
        
    }

    @Override
    public boolean isGoal() {
       return rushhour.isGameOver();
    }

    @Override
    public String toString() {
        StringBuilder retString = new StringBuilder();
        for (Move move : moves) {
            retString.append(move).append(" ");
        }
        return retString + "\n" + rushhour.board.toString();
    }

    public static RushHourSolver solve(RushHour initialConfig){
        Backtracker backtracker = new Backtracker<>(true);
        Configuration solution = backtracker.solve(new RushHourSolver(initialConfig));

        if(solution != null){
            return (RushHourSolver)solution;
        }
        else{
            return null;
        }
    }

     public ArrayList<Move> getMoves() {
        return moves;
    }

    
    

    public static void main(String[] args) throws IOException{

        RushHour rushHour = new RushHour("data/03_00.csv");
        RushHourSolver solution = RushHourSolver.solve(rushHour);
        System.out.println(solution);

        
    }


    

   
    
}
