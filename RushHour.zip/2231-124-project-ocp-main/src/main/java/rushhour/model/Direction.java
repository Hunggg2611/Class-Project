package rushhour.model;

public enum Direction {
    UP("up"),
    RIGHT("right"),
    DOWN("down"),
    LEFT("left");
    
    private final String directionString;
    //Constructor 
    private Direction(String directionString) {
        this.directionString = directionString;
    }

    public String getDirectionString() {
        return this.directionString;
    }

    public boolean isHorizontal() {
        return this == LEFT || this == RIGHT;
    }

    public boolean isVertical() {
        return this == UP || this == DOWN;
    }

    @Override
    public String toString() {
        return this.directionString.substring(0, 1).toUpperCase() + this.directionString.substring(1).toLowerCase();
    }
    
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
