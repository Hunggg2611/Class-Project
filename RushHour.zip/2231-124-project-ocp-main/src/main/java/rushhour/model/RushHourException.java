package rushhour.model;


public class RushHourException extends Exception {

    public RushHourException(String message) throws Exception{
        throw new java.lang.Exception(message);
    }

    
    
}
