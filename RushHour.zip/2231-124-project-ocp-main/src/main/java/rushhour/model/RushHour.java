package rushhour.model;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;



public class RushHour {
     
    public static final int BOARD_DIM = 6;
    public static final char RED_SYMBOL = 'R';
    public static final char EMPTY_SYMBOL = '-';
    public static final Position EXIT_POS = new Position(2, 5);
    public HashMap<Character,Vehicle> vehicleMap = new HashMap<>();
    public Board board;
    public Vehicle redVehicle;
    public String gameFileName = "";
    public int moveCount;
    private RushHourObserver observer;
    private ArrayList<Vehicle> vehiclesList = new ArrayList<>();


    public RushHour(String filename) throws IOException{
        this.board = new Board();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line = "";
            this.gameFileName = filename;
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split(",");
                char symbol = tokens[0].charAt(0);

                
                int backRow = Integer.parseInt(tokens[1]);
                int backCol = Integer.parseInt(tokens[2]);
                int frontRow = Integer.parseInt(tokens[3]);
                int frontCol = Integer.parseInt(tokens[4]);

                Position back = new Position(backRow, backCol);
                Position front = new Position(frontRow, frontCol);

                Vehicle vehicle = new Vehicle(symbol,back,front);
                if (symbol == 'R') {
                    redVehicle = vehicle;
                }
                vehicleMap.put(vehicle.getSymbol(),vehicle);
                vehiclesList.add(vehicle);
                board.placeVehicle(vehicle);
            } 
            
        } catch (IOException e) {
            throw new IOException();
        }
      

    }

    public RushHour(RushHour original) {


        this.gameFileName = original.gameFileName;
        this.moveCount = original.moveCount;

       
        this.board = new Board(original.board); 
        this.redVehicle = new Vehicle(original.redVehicle);
        // if(moveCount == 1){
        //     this.redVehicle = new Vehicle('R',new Position(2,0), new Position(2,1));
        // }
        
       
        this.vehiclesList = new ArrayList<>();
        for (Vehicle vehicle : original.vehiclesList) {
            this.vehiclesList.add(new Vehicle(vehicle));
        }

       
        this.vehicleMap = new HashMap<>();
        for (Map.Entry<Character, Vehicle> entry : original.vehicleMap.entrySet()) {
            Vehicle originalVehicle = entry.getValue();
            this.vehicleMap.put(entry.getKey(), new Vehicle(originalVehicle)); 
        }

    }

    public RushHour deepCopy() {
        return new RushHour(this); 
    }

    public boolean isGameOver(){
        if (redVehicle.getFront().getRow() == EXIT_POS.getRow() && redVehicle.getFront().getCol() == EXIT_POS.getCol()) {
            return true;
        }
        return false;
    }

    public void moveVehicle(Move move){

        if(vehicleMap.containsKey(move.getSymbol())){

            Vehicle vehicle = vehicleMap.get(move.getSymbol());

            if(vehicle.getSymbol() == move.getSymbol()){

                if(board.checkMove(move, vehicle)){
                    try {
                        board.removeVehicle(vehicle);
                        vehicle.move(move.getDir());
                        board.placeVehicle(vehicle);
                        moveCount++;
                        if(vehicle.getSymbol() == 'R'){
                            this.redVehicle = new Vehicle(vehicle);
                        }
                        
                    } catch (Exception e) {

                    }
                }
            }
        }
    }
               
    

    public void printBoard() {
        board.printBoard();
    }

    public void resetBoard(){
        RushHour rushHour;
        try {
            rushHour = new RushHour(gameFileName);
             this.board = rushHour.board;
        } catch (IOException e) {
           
        }
       
    }

    public int getMoveCount() {
        return moveCount;
    }

    public ArrayList<Move> getPossibleMoves() {
        ArrayList<Move> possibleMoves = new ArrayList<>();
        for (Vehicle vehicle : vehiclesList) {
            
            if(vehicle.isHorizontalVehicle()){
                try {
                        this.moveVehicle(new Move(vehicle.getSymbol(), Direction.LEFT));
                        this.moveVehicle(new Move(vehicle.getSymbol(), Direction.RIGHT));
                        possibleMoves.add(new Move(vehicle.getSymbol(), Direction.LEFT));
                        moveCount --;
                        moveCount--;
                    
                } catch (Exception e) {
                    
                }

               try {
                        this.moveVehicle(new Move(vehicle.getSymbol(), Direction.RIGHT));
                        this.moveVehicle(new Move(vehicle.getSymbol(), Direction.LEFT));
                        possibleMoves.add(new Move(vehicle.getSymbol(), Direction.RIGHT));
                        moveCount --;
                        moveCount--;
                    
                } catch (Exception e) {
                    
                }
                
            }

            if(vehicle.isVerticalVehicle()){
                 try {
                        this.moveVehicle(new Move(vehicle.getSymbol(), Direction.UP));
                        this.moveVehicle(new Move(vehicle.getSymbol(), Direction.DOWN));
                        possibleMoves.add(new Move(vehicle.getSymbol(), Direction.UP));
                        moveCount --;
                        moveCount--;

                    
                } catch (Exception e) {
                    
                }

                try {
                        this.moveVehicle(new Move(vehicle.getSymbol(), Direction.DOWN));
                        this.moveVehicle(new Move(vehicle.getSymbol(), Direction.UP));
                        possibleMoves.add(new Move(vehicle.getSymbol(), Direction.DOWN));
                        moveCount--;
                        moveCount--;
                    
                } catch (Exception e) {
                    
                }

            }
        }
        return possibleMoves;
    }

    public ArrayList<Vehicle> getVehiclesList(){
        return this.vehiclesList;
    }

    
    public HashMap<Character, Vehicle> getVehicles() {
        return vehicleMap;
    }

    public void registerObserver(RushHourObserver observer){
        this.observer = observer;
    }

    public void notifyObserver(Vehicle vehicle){
        this.observer.vehicleMoved(vehicle);
    }

    public boolean canMoveRedRight(){

        if(this.isGameOver()){
            return false;
        }

        if(this.board.isSpaceEmpty(redVehicle.getFront().getRow(), redVehicle.getFront().getCol()+1)){
            return true;
        }
        
        else{
            return false;
        }
    }

    

    



    public static void main(String[] args){
        
        try {

            RushHour rushHour = new RushHour("data/03_00.csv");
            rushHour.board.printBoard();

            System.out.println('\n');

            rushHour.moveVehicle(new Move('O', Direction.UP));
            rushHour.moveVehicle(new Move('O', Direction.UP));
            rushHour.board.printBoard();
          
        
           

           
            // rushHour.board.printBoard();
            // System.out.println(rushHour.getPossibleMoves());
            // System.out.println(rushHour.getMoveCount());
            


        } catch (IOException e) {
            System.out.println("File Error");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

  

  

 

}
