package rushhour.model;

public interface RushHourObserver {

    public void vehicleMoved(Vehicle vehicle);
}
