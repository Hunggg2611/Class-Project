package rushhour.model;


public class Board {

    
    private int size = 6; 
    private char[][] board = new char[size][size];

    public Board(){
        
        for(int row = 0; row < size; row++){
            for(int col = 0; col < size; col ++){
                board[row][col] = RushHour.EMPTY_SYMBOL;
            }
        }
    }

    public void placeVehicle(Vehicle vehicle){

        board[vehicle.getBack().getRow()][vehicle.getBack().getCol()] = vehicle.getSymbol();
        board[vehicle.getFront().getRow()][vehicle.getFront().getCol()] = vehicle.getSymbol();

        if(vehicle.getMiddle() != null){
            board[vehicle.getMiddle().getRow()][vehicle.getMiddle().getCol()] = vehicle.getSymbol();
        }
    }

    public void removeVehicle(Vehicle vehicle){

        board[vehicle.getBack().getRow()][vehicle.getBack().getCol()] = RushHour.EMPTY_SYMBOL;
        board[vehicle.getFront().getRow()][vehicle.getFront().getCol()] = RushHour.EMPTY_SYMBOL;

        if(vehicle.getMiddle() != null){
            board[vehicle.getMiddle().getRow()][vehicle.getMiddle().getCol()] = RushHour.EMPTY_SYMBOL;
        }
    }

 
    @Override 
    public String toString(){
        String retString = "";
        for(int row = 0; row < size; row ++){
            for(int col = 0; col < size; col ++){
                if(col == 5){
                    retString += board[row][col] + "" + '\n';
                    continue;
                }
                else{
                    retString += board[row][col] + " ";
                }
                
            }
        }
        return retString;
    }

    public void printBoard(){

         for(int row = 0; row < size; row++){
            for(int col = 0; col < size; col ++){
                System.out.print(board[row][col] + " ");
            }
            System.out.println();
        }
    }

    public boolean isSpaceEmpty(int row, int col) {

        if (board[row][col] == RushHour.EMPTY_SYMBOL) {
            return true;
        }
        return false;
    }

    public boolean checkMove(Move move, Vehicle vehicle){

        //Covers vehicles that take up 2 spaces
        if(vehicle.getLength() == 1){

            if(move.getDir() == Direction.LEFT && vehicle.isHorizontalVehicle()){
                if(isSpaceEmpty(vehicle.getBack().getRow(), vehicle.getBack().getCol()-1)){
                    return true;
                }
            }

            if(move.getDir() == Direction.RIGHT && vehicle.isHorizontalVehicle()){
                if(isSpaceEmpty(vehicle.getFront().getRow(),vehicle.getFront().getCol()+1)){
                    return true;
                }
            }

            if(move.getDir() == Direction.UP && vehicle.isVerticalVehicle()){
                if(isSpaceEmpty(vehicle.getFront().getRow()+1,vehicle.getFront().getCol())){
                    return true;
                }

            }

            if(move.getDir() == Direction.DOWN && vehicle.isVerticalVehicle()){
                if(isSpaceEmpty(vehicle.getBack().getRow()-1, vehicle.getBack().getCol())){
                    return true;
                }

            }

        //Covers vehicles that take up 3 spaces honestly the code below was a mistake and i just dont have the energy to remove it and see if its actually not needed
        //But im 99.99% sure that its redundant 
        }else{

            if(move.getDir() == Direction.LEFT && vehicle.isHorizontalVehicle()){
                if(isSpaceEmpty(vehicle.getBack().getRow(), vehicle.getBack().getCol()-1)){
                    return true;
                }
            }

            if(move.getDir() == Direction.RIGHT && vehicle.isHorizontalVehicle()){
                if(isSpaceEmpty(vehicle.getBack().getRow(), vehicle.getBack().getCol()+1)){
                    return true;
                }
            }

            if(move.getDir() == Direction.UP && vehicle.isVerticalVehicle()){
                if(isSpaceEmpty(vehicle.getFront().getRow()+1,vehicle.getFront().getCol())){
                    return true;
                }

            }

            if(move.getDir() == Direction.DOWN && vehicle.isVerticalVehicle()){
                if(isSpaceEmpty(vehicle.getBack().getRow()-1, vehicle.getBack().getCol())){
                    return true;
                }

            }

        }

        return false;
    }

    public Board(Board original) {
        this.size = original.size;
        this.board = new char[size][size];
        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                this.board[row][col] = original.board[row][col];
            }
        }
    }
    
    public Board deepCopy() {
        return new Board(this); 
    }




    public static void main(String[] args){
        Board board = new Board();
        board.printBoard();
        System.out.println('\n');
        System.out.println(board);

    }
 
    
}
