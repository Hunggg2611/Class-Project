package rushhour.model;

public class Move {

    private char symbol;
    private Direction dir;

    public Move(char symbol, Direction dir){
        this.symbol = symbol;
        this.dir = dir;
    }

    public char getSymbol() {
        return symbol;
    }

    public Direction getDir() {
        return dir;
    }

    @Override
    public String toString() {
        return "[Move: " + symbol + " " + dir.toString().toUpperCase() + "]";
    }

    
    
}
